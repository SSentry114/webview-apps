import 'package:flutter/material.dart';
import 'package:user_screen/src/generated/l10n.dart';
import 'package:user_screen/src/navigation/app_state_manager.dart';
import 'package:user_screen/src/habits/habits_manager.dart';
import 'package:provider/provider.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            height:
                110, // Reduced from default DrawerHeader height (usually 160)
            padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 40.0),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
            ),
            alignment: Alignment.centerLeft,
            child: Text(
              'A Bit Better',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onPrimary,
                  ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.list),
            title: Text("Habit Tracking"),
            onTap: () {
              Navigator.pop(context); // Close drawer
              // Just close drawer as we're already on habits screen
            },
          ),
          ListTile(
            leading: const Icon(Icons.bar_chart),
            title: Text(S.of(context).statistics),
            onTap: () {
              Navigator.pop(context); // Close drawer
              Provider.of<HabitsManager>(context, listen: false).hideSnackBar();
              final appStateManager =
                  Provider.of<AppStateManager>(context, listen: false);
              // Clear other states before setting statistics
              appStateManager.goArchivedHabits(false);
              appStateManager.goSettings(false);
              appStateManager.goStatistics(true);
            },
          ),
          ListTile(
            leading: const Icon(Icons.archive),
            title: Text(S.of(context).archivedHabits),
            onTap: () {
              Navigator.pop(context); // Close drawer
              Provider.of<AppStateManager>(context, listen: false)
                  .goArchivedHabits(true);
            },
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: Text(S.of(context).settings),
            onTap: () {
              Navigator.pop(context); // Close drawer
              Provider.of<AppStateManager>(context, listen: false)
                  .goSettings(true);
            },
          ),
        ],
      ),
    );
  }
}
