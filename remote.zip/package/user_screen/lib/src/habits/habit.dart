import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:user_screen/src/model/category.dart';
import 'package:user_screen/src/model/habit_data.dart';
import 'package:user_screen/src/habits/habit_header.dart';
import 'package:user_screen/src/habits/one_day.dart';
import 'package:user_screen/src/habits/one_day_button.dart';
import 'package:user_screen/src/helpers.dart';
import 'package:user_screen/src/constants.dart';
import 'package:user_screen/src/generated/l10n.dart';
import 'package:user_screen/src/navigation/app_state_manager.dart';
import 'package:user_screen/src/settings/settings_manager.dart';
import 'package:user_screen/src/habits/habits_manager.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:user_screen/src/extensions.dart';
import 'package:user_screen/src/widgets/progress_input_modal.dart';

class Habit extends StatefulWidget {
  const Habit({super.key, required HabitData habitData})
    : _habitData = habitData;

  final HabitData _habitData;
  HabitData get habitData => _habitData;

  set setId(int input) {
    _habitData.id = input;
  }

  Map<String, dynamic> toMap() {
    return {
      'id': _habitData.id,
      'title': _habitData.title,
      'twoDayRule': _habitData.twoDayRule ? 1 : 0,
      'position': _habitData.position,
      'cue': _habitData.cue,
      'routine': _habitData.routine,
      'reward': _habitData.reward,
      'showReward': _habitData.showReward ? 1 : 0,
      'advanced': _habitData.advanced ? 1 : 0,
      'notification': _habitData.notification ? 1 : 0,
      'notTime': '${_habitData.notTime.hour}:${_habitData.notTime.minute}',
      'sanction': _habitData.sanction,
      'showSanction': _habitData.showSanction ? 1 : 0,
      'accountant': _habitData.accountant,
      'habitType': _habitData.habitType.index,
      'targetValue': _habitData.targetValue,
      'partialValue': _habitData.partialValue,
      'unit': _habitData.unit,
      'archived': _habitData.archived ? 1 : 0,
    };
  }

  Map<String, dynamic> toJson() {
    return {
      'id': habitData.id,
      'title': habitData.title,
      'twoDayRule': habitData.twoDayRule ? 1 : 0,
      'position': habitData.position,
      'cue': habitData.cue,
      'routine': habitData.routine,
      'reward': habitData.reward,
      'showReward': habitData.showReward ? 1 : 0,
      'advanced': habitData.advanced ? 1 : 0,
      'notification': habitData.notification ? 1 : 0,
      'notTime': '${habitData.notTime.hour}:${habitData.notTime.minute}',
      'events': habitData.events.map((key, value) {
        return MapEntry(
          key.toString(),
          value.length > 2
              ? [value[0].toString(), value[1], value[2]]
              : [value[0].toString(), value[1]],
        );
      }),
      'sanction': habitData.sanction,
      'showSanction': habitData.showSanction ? 1 : 0,
      'accountant': habitData.accountant,
      'habitType': habitData.habitType.index,
      'targetValue': habitData.targetValue,
      'partialValue': habitData.partialValue,
      'unit': habitData.unit,
      'categories': habitData.categories
          .map((category) => category as Category)
          .map((category) => category.toJson())
          .toList(),
      'archived': habitData.archived ? 1 : 0,
    };
  }

  Habit.fromJson(Map<String, dynamic> json, {super.key})
    : _habitData = HabitData(
        id: json['id'],
        position: json['position'],
        title: json['title'],
        twoDayRule: json['twoDayRule'] != 0 ? true : false,
        cue: json['cue'],
        routine: json['routine'],
        reward: json['reward'],
        showReward: json['showReward'] != 0 ? true : false,
        advanced: json['advanced'] != 0 ? true : false,
        notification: json['notification'] != 0 ? true : false,
        notTime: parseTimeOfDay(json['notTime']),
        events: doEvents(json['events']),
        sanction: json['sanction'] ?? '',
        showSanction: (json['showSanction'] ?? 0) != 0 ? true : false,
        accountant: json['accountant'] ?? '',
        habitType: HabitType.values[json['habitType'] ?? 0],
        targetValue: (json['targetValue'] ?? 1.0).toDouble(),
        partialValue: (json['partialValue'] ?? 1.0).toDouble(),
        unit: json['unit'] ?? '',
        categories: json['categories'] != null
            ? (json['categories'] as List)
                  .map((categoryJson) => Category.fromJson(categoryJson))
                  .toList()
            : [],
        archived: (json['archived'] ?? 0) != 0 ? true : false,
      );

  static SplayTreeMap<DateTime, List> doEvents(Map<String, dynamic> input) {
    SplayTreeMap<DateTime, List> result = SplayTreeMap<DateTime, List>();

    input.forEach((key, value) {
      final dayType = DayType.values.firstWhere(
        (e) => e.toString() == reformatOld(value[0]),
      );
      final comment = value[1];

      // Handle progress data for numeric habits
      if (value.length > 2 && dayType == DayType.progress) {
        final progressValue = (value[2] as num?)?.toDouble() ?? 0.0;
        result[DateTime.parse(key)] = [dayType, comment, progressValue];
      } else {
        result[DateTime.parse(key)] = [dayType, comment];
      }
    });
    return result;
  }

  // To be compatible with older version backup
  static String reformatOld(String value) {
    var all = value.split('.');
    return '${all[0]}.${all[1].toLowerCase()}';
  }

  void navigateToEditPage(BuildContext context) {
    Provider.of<AppStateManager>(context, listen: false).goEditHabit(habitData);
  }

  @override
  State<Habit> createState() => HabitState();
}

class HabitState extends State<Habit> {
  // State variables
  CalendarFormat _calendarFormat = CalendarFormat.week;
  bool _showMonth = false;
  String _actualMonth = '';
  DateTime _focusedDay = DateTime.now();
  DateTime _selectedDay = DateTime.now();
  int _rebuildKey = 0; // Key to force calendar rebuild

  // Properties
  HabitData get habitData => widget.habitData;

  // Generate a consistent pastel color based on habit ID
  Color get cardBackgroundColor {
    final id = widget.habitData.id ?? 0;
    final hue = (id * 137.5) % 360; // Golden angle distribution
    return HSLColor.fromAHSL(1.0, hue, 0.25, 0.95).toColor();
  }

  // Navigation and selection methods
  void setSelectedDay(DateTime date) {
    if (!isSameDay(_selectedDay, date)) {
      setState(() {
        _selectedDay = date;
        _focusedDay = date;
        _updateMonth(date);
      });
    }
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    setSelectedDay(selectedDay);
    _showDateOptions(selectedDay);
  }

  void _showDateOptions(DateTime date) {
    final transformedDate = transformDate(date);
    final event = widget.habitData.events[transformedDate];
    final habitsManager = Provider.of<HabitsManager>(context, listen: false);
    final settingsManager = Provider.of<SettingsManager>(
      context,
      listen: false,
    );

    String comment = '';
    if (event != null &&
        event.length > 1 &&
        event[1] != null &&
        event[1] != '') {
      comment = event[1];
    }

    // Build options list
    final options = <Map<String, dynamic>>[
      {
        'key': 'Check',
        'label': S.of(context).check,
        'icon': Icons.check,
        'color': settingsManager.checkColor,
      },
      if (widget.habitData.isNumeric)
        {
          'key': 'Plus',
          'label': S.of(context).progress,
          'icon': Icons.add,
          'color': settingsManager.progressColor,
        },
      {
        'key': 'Fail',
        'label': S.of(context).fail,
        'icon': Icons.close,
        'color': settingsManager.failColor,
      },
      {
        'key': 'Skip',
        'label': S.of(context).skip,
        'icon': Icons.last_page,
        'color': settingsManager.skipColor,
      },
      {
        'key': 'Comment',
        'label': S.of(context).note,
        'icon': Icons.chat_bubble_outline,
        'color': HaboColors.orange,
      },
      {
        'key': 'Clear',
        'label': 'Clear',
        'icon': Icons.delete,
        'color': Colors.grey,
      },
    ];

    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return SimpleDialog(
          title: Text('${date.day}'),
          children: options.map((option) {
            return SimpleDialogOption(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                _handleDateAction(
                  transformedDate,
                  option['key'] as String,
                  comment,
                  habitsManager,
                  settingsManager,
                );
              },
              child: Row(
                children: [
                  Icon(
                    option['icon'] as IconData,
                    color: option['color'] as Color,
                  ),
                  SizedBox(width: 16),
                  Text(option['label'] as String),
                ],
              ),
            );
          }).toList(),
        );
      },
    );
  }

  void _handleDateAction(
    DateTime date,
    String action,
    String comment,
    HabitsManager habitsManager,
    SettingsManager settingsManager,
  ) {
    final int id = widget.habitData.id!;

    switch (action) {
      case 'Check':
        settingsManager.playCheckSound();
        habitsManager.addEvent(id, date, [DayType.check, comment]);
        widget.habitData.events[date] = [DayType.check, comment];
        showRewardNotification(date);
        break;

      case 'Fail':
        settingsManager.playClickSound();
        habitsManager.addEvent(id, date, [DayType.fail, comment]);
        widget.habitData.events[date] = [DayType.fail, comment];
        showSanctionNotification(date);
        break;

      case 'Skip':
        settingsManager.playClickSound();
        habitsManager.addEvent(id, date, [DayType.skip, comment]);
        widget.habitData.events[date] = [DayType.skip, comment];
        break;

      case 'Plus':
        _showProgressInput(date, habitsManager, settingsManager);
        return; // Don't refresh yet, will refresh after progress input

      case 'Comment':
        _showCommentInput(date, comment, habitsManager);
        return; // Don't refresh yet, will refresh after comment input

      case 'Clear':
        if (comment != '') {
          habitsManager.addEvent(id, date, [DayType.clear, comment]);
          widget.habitData.events[date] = [DayType.clear, comment];
        } else {
          habitsManager.deleteEvent(id, date);
          widget.habitData.events.remove(date);
        }
        break;
    }

    refresh();
  }

  void _showProgressInput(
    DateTime date,
    HabitsManager habitsManager,
    SettingsManager settingsManager,
  ) {
    final habitData = widget.habitData;
    final currentProgress = habitData.getProgressForDate(date);
    final int id = habitData.id!;

    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return ProgressInputModal(
          habitTitle: habitData.title,
          targetValue: habitData.targetValue,
          partialValue: habitData.partialValue,
          unit: habitData.unit,
          currentProgress: currentProgress,
          onProgressChanged: (double progressValue) {
            habitsManager.addEvent(id, date, [
              DayType.progress,
              '',
              progressValue,
            ]);
            habitData.events[date] = [DayType.progress, '', progressValue];

            if (progressValue >= habitData.targetValue) {
              showRewardNotification(date);
              settingsManager.playCheckSound();
            } else {
              settingsManager.playClickSound();
            }

            refresh();
          },
        );
      },
    );
  }

  void _showCommentInput(
    DateTime date,
    String existingComment,
    HabitsManager habitsManager,
  ) {
    final int id = widget.habitData.id!;
    TextEditingController commentController = TextEditingController(
      text: existingComment,
    );

    final currentEvent = widget.habitData.events[date];
    int dayTypeIndex = 0;
    if (currentEvent != null && currentEvent[0] is DayType) {
      dayTypeIndex = (currentEvent[0] as DayType).index;
    }

    final noteText = S.of(context).note;
    final hintText = S.of(context).yourCommentHere;
    final closeText = S.of(context).close;
    final saveText = S.of(context).save;

    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(noteText),
          content: TextField(
            controller: commentController,
            autofocus: true,
            maxLines: 5,
            decoration: InputDecoration(
              hintText: hintText,
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: Text(closeText),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                habitsManager.addEvent(id, date, [
                  DayType.values[dayTypeIndex],
                  commentController.text,
                ]);
                widget.habitData.events[date] = [
                  DayType.values[dayTypeIndex],
                  commentController.text,
                ];
                refresh();
              },
              child: Text(saveText),
            ),
          ],
        );
      },
    );
  }

  void _onFormatChanged(CalendarFormat format) {
    if (_calendarFormat != format) {
      setState(() {
        _calendarFormat = format;
        _updateMonth(_selectedDay);
      });
    }
  }

  // UI update methods
  void _updateMonth(DateTime selectedDay) {
    _showMonth = (_calendarFormat == CalendarFormat.month);
    _actualMonth = DateFormat(
      'yMMMM',
      Intl.getCurrentLocale(),
    ).format(selectedDay).capitalize();
  }

  void refresh() {
    setState(() {
      _rebuildKey++; // Increment to force calendar rebuild
      _updateLastStreak();
      _updateMonth(_selectedDay);
    });
  }

  // Lifecycle methods
  @override
  void initState() {
    super.initState();
    _updateLastStreak();
    _updateMonth(_selectedDay);
  }

  @override
  void didUpdateWidget(Habit oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Rebuild when habit data changes
    if (oldWidget.habitData != widget.habitData ||
        oldWidget.habitData.title != widget.habitData.title ||
        oldWidget.habitData.habitType != widget.habitData.habitType) {
      setState(() {
        _updateLastStreak();
        _updateMonth(_selectedDay);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key('habit_${widget.habitData.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20.0),
        color: Colors.orange,
        child: const Icon(Icons.archive, color: Colors.white, size: 32),
      ),
      confirmDismiss: (direction) async {
        return await showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text(S.of(context).archiveHabit),
              content: Text('${S.of(context).archiveHabit}?'),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: Text(S.of(context).cancel),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: Text(S.of(context).archive),
                ),
              ],
            );
          },
        );
      },
      onDismissed: (direction) {
        final habitId = widget.habitData.id!;

        // Archive the habit
        Provider.of<HabitsManager>(
          context,
          listen: false,
        ).archiveHabit(habitId);

        // Show snackbar
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(S.of(context).habitArchived),
            action: SnackBarAction(
              label: S.of(context).undo,
              onPressed: () {
                // Unarchive the habit
                Provider.of<HabitsManager>(
                  context,
                  listen: false,
                ).unarchiveHabit(habitId);
              },
            ),
          ),
        );
      },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
        elevation: 2.0,
        color: cardBackgroundColor,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              HabitHeader(
                habitData: widget.habitData.title,
                onEditPressed: () => widget.navigateToEditPage(context),
                isSmall: true,
              ),
              if (_showMonth &&
                  Provider.of<SettingsManager>(context).getShowMonthName)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4.0),
                  child: Text(_actualMonth),
                ),
              TableCalendar<List<dynamic>>(
                key: ValueKey('calendar_${widget.habitData.id}_$_rebuildKey'),
                focusedDay: _focusedDay,
                firstDay: DateTime(2000),
                lastDay: DateTime.now(),
                headerVisible: false,
                currentDay: DateTime.now(),
                calendarFormat: _calendarFormat,
                daysOfWeekVisible: false,
                onFormatChanged: _onFormatChanged,
                onPageChanged: setSelectedDay,
                onDaySelected: _onDaySelected,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                startingDayOfWeek: Provider.of<SettingsManager>(
                  context,
                ).getWeekStartEnum,
                availableCalendarFormats: {
                  CalendarFormat.month: S.of(context).month,
                  CalendarFormat.week: S.of(context).week,
                },
                eventLoader: (day) {
                  final event = widget.habitData.events[transformDate(day)];
                  return event != null ? [event] : [];
                },
                calendarBuilders: CalendarBuilders<List<dynamic>>(
                  defaultBuilder: (context, date, events) => OneDayButton(
                    callback: refresh,
                    parent: this,
                    id: widget.habitData.id!,
                    date: date,
                    color: Theme.of(context).colorScheme.primaryContainer,
                    event: widget.habitData.events[transformDate(date)],
                  ),
                  todayBuilder: (context, date, events) => OneDayButton(
                    callback: refresh,
                    parent: this,
                    id: widget.habitData.id!,
                    date: date,
                    color: Theme.of(context).colorScheme.primaryContainer,
                    event: widget.habitData.events[transformDate(date)],
                  ),
                  disabledBuilder: (context, date, events) => OneDay(
                    date: date,
                    color: Theme.of(context).colorScheme.secondaryContainer,
                    child: Text(
                      date.day.toString(),
                      style: TextStyle(
                        color: (date.weekday > 5) ? Colors.red[300] : null,
                      ),
                    ),
                  ),
                  outsideBuilder: (context, date, events) => OneDay(
                    date: date,
                    color: Theme.of(context).colorScheme.secondaryContainer,
                    child: Text(
                      date.day.toString(),
                      style: TextStyle(
                        color: (date.weekday > 5) ? Colors.red[300] : null,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _updateLastStreak() {
    if (widget.habitData.twoDayRule == true) {
      _updateLastStreakTwoDay();
    } else {
      _updateLastStreakNormal();
    }
  }

  void _updateLastStreakNormal() {
    int inStreak = 0;
    var checkDayKey = widget.habitData.events.lastKey();
    var lastDayKey = widget.habitData.events.lastKey();

    while (widget.habitData.events[checkDayKey] != null &&
        widget.habitData.events[checkDayKey]![0] != DayType.fail) {
      if (widget.habitData.events[checkDayKey]![0] != DayType.clear) {
        if (widget.habitData.events[lastDayKey]![0] != null &&
            widget.habitData.events[lastDayKey]![0] != DayType.clear &&
            lastDayKey!.difference(checkDayKey!).inDays > 1) {
          break;
        }
        lastDayKey = checkDayKey;
      }

      if (widget.habitData.events[checkDayKey]![0] == DayType.check ||
          (widget.habitData.events[checkDayKey]![0] == DayType.progress &&
              widget.habitData.events[checkDayKey]![2] >=
                  widget.habitData.targetValue)) {
        inStreak++;
      }
      checkDayKey = widget.habitData.events.lastKeyBefore(checkDayKey!);
    }

    widget.habitData.streak = inStreak;
  }

  void _updateLastStreakTwoDay() {
    int inStreak = 0;
    var trueLastKey = widget.habitData.events.lastKey();

    while (widget.habitData.events[trueLastKey] != null &&
        widget.habitData.events[trueLastKey]![0] != null &&
        (widget.habitData.events[trueLastKey]![0] == DayType.clear ||
            (widget.habitData.events[trueLastKey]![0] == DayType.progress &&
                widget.habitData.events[trueLastKey]![2] <
                    widget.habitData.targetValue))) {
      trueLastKey = widget.habitData.events.lastKeyBefore(trueLastKey!);
    }

    var checkDayKey = trueLastKey;
    var lastDayKey = trueLastKey;
    DayType lastDay = DayType.check;

    while (widget.habitData.events[checkDayKey] != null) {
      if (widget.habitData.events[checkDayKey]![0] != DayType.clear) {
        if (widget.habitData.events[checkDayKey]![0] == DayType.fail &&
            (lastDay != DayType.check &&
                lastDay != DayType.clear &&
                lastDay != DayType.progress)) {
          break;
        }

        if (widget.habitData.events[lastDayKey]![0] != null &&
            widget.habitData.events[lastDayKey]![0] != DayType.clear &&
            lastDayKey!.difference(checkDayKey!).inDays > 1) {
          break;
        }

        lastDayKey = checkDayKey;
      }

      lastDay = widget.habitData.events[checkDayKey]![0];
      if (widget.habitData.events[checkDayKey]![0] == DayType.check ||
          (widget.habitData.events[checkDayKey]![0] == DayType.progress &&
              widget.habitData.events[checkDayKey]![2] >=
                  widget.habitData.targetValue)) {
        inStreak++;
      }
      checkDayKey = widget.habitData.events.lastKeyBefore(checkDayKey!);
    }

    widget.habitData.streak = inStreak;
  }

  // Notification methods
  void showRewardNotification(DateTime date) {
    if (isSameDay(date, DateTime.now()) &&
        widget.habitData.showReward &&
        widget.habitData.reward != '') {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          duration: const Duration(seconds: 2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          content: Text(
            '${S.of(context).congratulationsReward}\n${widget.habitData.reward}',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white),
          ),
          backgroundColor: Theme.of(context).colorScheme.primary,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void showSanctionNotification(DateTime date) {
    if (isSameDay(date, DateTime.now()) &&
        widget.habitData.showSanction &&
        widget.habitData.sanction != '') {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          duration: const Duration(seconds: 2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          content: Text(
            '${S.of(context).ohNoSanction}\n${widget.habitData.sanction}',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white),
          ),
          backgroundColor: Provider.of<SettingsManager>(
            context,
            listen: false,
          ).failColor,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }
}
