import 'package:flutter/material.dart';

class HabitHeader extends StatelessWidget {
  const HabitHeader({
    super.key,
    required this.habitData,
    this.onEditPressed,
    this.isSmall = false,
  });

  final String habitData;
  final VoidCallback? onEditPressed;
  final bool isSmall;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            habitData,
            style: TextStyle(
              fontSize: isSmall ? 16.0 : 20.0,
              fontWeight: FontWeight.bold,
              color: Theme.of(context).textTheme.bodyLarge?.color,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        IconButton(
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(minWidth: 32),
          icon: const Icon(Icons.edit_outlined),
          color: Colors.grey,
          onPressed: onEditPressed,
        ),
      ],
    );
  }
}
