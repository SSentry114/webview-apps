import 'package:flutter/material.dart';
import 'package:user_screen/src/constants.dart';
import 'package:user_screen/src/generated/l10n.dart';
import 'package:user_screen/src/habits/habit.dart';
import 'package:user_screen/src/habits/in_button.dart';
import 'package:user_screen/src/helpers.dart';
import 'package:user_screen/src/settings/settings_manager.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';

class OneDayButton extends StatelessWidget {
  OneDayButton({
    super.key,
    required date,
    this.color,
    this.child,
    required this.id,
    required this.parent,
    required this.callback,
    required this.event,
  }) : date = transformDate(date);

  final int id;
  final DateTime date;
  final Color? color;
  final Widget? child;
  final HabitState parent;
  final void Function() callback;
  final List? event;

  @override
  Widget build(BuildContext context) {
    List<InButton> icons = [
      InButton(
        key: const Key('Date'),
        text:
            child ??
            Text(
              date.day.toString(),
              style: TextStyle(
                color: (date.weekday > 5) ? Colors.red[300] : null,
                fontWeight: (isSameDay(date, DateTime.now()))
                    ? FontWeight.w900
                    : FontWeight.normal,
                fontSize: (isSameDay(date, DateTime.now())) ? 17 : null,
              ),
              textAlign: TextAlign.center,
            ),
      ),
      InButton(
        key: const Key('Check'),
        icon: Icon(
          Icons.check,
          color: Provider.of<SettingsManager>(
            context,
            listen: false,
          ).checkColor,
          semanticLabel: S.of(context).check,
        ),
      ),
      // Add plus icon for numeric habits
      if (parent.widget.habitData.isNumeric)
        InButton(
          key: const Key('Plus'),
          icon: Icon(
            Icons.add,
            color: Provider.of<SettingsManager>(
              context,
              listen: false,
            ).progressColor,
            semanticLabel: 'Add Progress',
          ),
        ),
      InButton(
        key: const Key('Fail'),
        icon: Icon(
          Icons.close,
          color: Provider.of<SettingsManager>(context, listen: false).failColor,
          semanticLabel: S.of(context).fail,
        ),
      ),
      InButton(
        key: const Key('Skip'),
        icon: Icon(
          Icons.last_page,
          color: Provider.of<SettingsManager>(context, listen: false).skipColor,
          semanticLabel: S.of(context).skip,
        ),
      ),
      InButton(
        key: const Key('Comment'),
        icon: Icon(
          Icons.chat_bubble_outline,
          semanticLabel: S.of(context).note,
          color: HaboColors.orange,
        ),
      ),
    ];

    String comment = '';
    if (event != null &&
        event!.length > 1 &&
        event![1] != null &&
        event![1] != '') {
      comment = (event![1]);
    }

    // Determine background color based on event type
    Color backgroundColor =
        color ?? Theme.of(context).colorScheme.primaryContainer;
    Widget displayWidget = icons[0]; // Default to date

    if (event != null && event![0] is DayType) {
      final dayType = event![0] as DayType;
      final settingsManager = Provider.of<SettingsManager>(
        context,
        listen: false,
      );

      switch (dayType) {
        case DayType.check:
          backgroundColor = settingsManager.checkColor;
          displayWidget = Icon(Icons.check, color: Colors.white);
          break;
        case DayType.fail:
          backgroundColor = settingsManager.failColor;
          displayWidget = Icon(Icons.close, color: Colors.white);
          break;
        case DayType.skip:
          backgroundColor = settingsManager.skipColor;
          displayWidget = Icon(Icons.last_page, color: Colors.white);
          break;
        case DayType.progress:
          if (parent.widget.habitData.isNumeric && event!.length > 2) {
            final progressValue = (event![2] as num?)?.toDouble() ?? 0.0;
            if (progressValue >= parent.widget.habitData.targetValue) {
              backgroundColor = settingsManager.checkColor;
              displayWidget = Icon(Icons.check, color: Colors.white);
            } else {
              backgroundColor = settingsManager.progressColor;
              final percentage =
                  (progressValue / parent.widget.habitData.targetValue).clamp(
                    0.0,
                    1.0,
                  );
              displayWidget = Text(
                '${(percentage * 100).round()}%',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              );
            }
          }
          break;
        case DayType.clear:
          backgroundColor =
              color ?? Theme.of(context).colorScheme.primaryContainer;
          displayWidget = icons[0]; // Show date
          break;
      }
    } else {
      // No event, show default date
      displayWidget = icons[0];
    }

    return AspectRatio(
      aspectRatio: 1,
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(4.0),
          child: Material(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(10.0),
            elevation: 2,
            shadowColor: Theme.of(context).shadowColor,
            child: Stack(
              children: [
                Container(
                  width: double.infinity,
                  height: double.infinity,
                  alignment: Alignment.center,
                  child: displayWidget,
                ),
                // Show orange dot only if there's a comment/note
                if (comment != '')
                  Positioned(
                    right: 4,
                    bottom: 4,
                    child: Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: HaboColors.orange,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
