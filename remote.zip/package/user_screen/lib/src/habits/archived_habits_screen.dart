import 'package:flutter/material.dart';
import 'package:user_screen/src/generated/l10n.dart';
import 'package:user_screen/src/navigation/app_state_manager.dart';
import 'package:user_screen/src/habits/habits_manager.dart';
import 'package:user_screen/src/navigation/routes.dart';
import 'package:provider/provider.dart';

class ArchivedHabitsScreen extends StatelessWidget {
  static MaterialPage page() {
    return MaterialPage(
      name: Routes.archivedHabitsPath,
      key: ValueKey(Routes.archivedHabitsPath),
      child: const ArchivedHabitsScreen(),
    );
  }

  const ArchivedHabitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<HabitsManager>(
      builder: (context, habitsManager, child) {
        final archivedHabits = habitsManager.archivedHabits;

        return Scaffold(
          appBar: AppBar(
            title: Text(S.of(context).archivedHabits),
            backgroundColor: Colors.transparent,
          ),
          body: archivedHabits.isEmpty
              ? Center(
                  child: Text(
                    S.of(context).noArchivedHabits,
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                )
              : ListView.builder(
                  itemCount: archivedHabits.length,
                  padding: const EdgeInsets.all(16),
                  itemBuilder: (context, index) {
                    final habit = archivedHabits[index];
                    return Card(
                      child: ListTile(
                        title: Text(habit.habitData.title),
                        trailing: IconButton(
                          icon: const Icon(Icons.unarchive),
                          onPressed: () {
                            habitsManager.unarchiveHabit(habit.habitData.id!);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(S.of(context).habitUnarchived),
                              ),
                            );
                          },
                          tooltip: S.of(context).unarchiveHabit,
                        ),
                        onTap: () {
                          Provider.of<AppStateManager>(context, listen: false)
                              .goEditHabit(habit.habitData);
                        },
                      ),
                    );
                  },
                ),
        );
      },
    );
  }
}
