import 'package:flutter/material.dart';
import 'package:user_screen/src/generated/l10n.dart';
import 'package:user_screen/src/settings/settings_manager.dart';
import 'package:user_screen/src/statistics/monthly_graph.dart';
import 'package:user_screen/src/statistics/statistics.dart';
import 'package:provider/provider.dart';

class StatisticsCard extends StatelessWidget {
  const StatisticsCard({
    super.key,
    required this.data,
  });

  final StatisticsData data;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).shadowColor.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            Text(
              data.title,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurface,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
            const SizedBox(height: 20),

            // Streaks section
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .primaryContainer
                    .withOpacity(0.5),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: _buildStreakItem(
                      context,
                      Icons.local_fire_department,
                      S.of(context).topStreak,
                      data.topStreak.toString(),
                      Colors.orange,
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 50,
                    color: Theme.of(context).dividerColor,
                  ),
                  Expanded(
                    child: _buildStreakItem(
                      context,
                      Icons.whatshot,
                      S.of(context).currentStreak,
                      data.actualStreak.toString(),
                      Colors.deepOrange,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Total label
            Text(
              S.of(context).total,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 12),

            // Stats grid
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatChip(
                  context,
                  Icons.check_circle,
                  data.checks.toString(),
                  Provider.of<SettingsManager>(context, listen: false)
                      .checkColor,
                ),
                _buildStatChip(
                  context,
                  Icons.trending_up,
                  data.progress.toString(),
                  Provider.of<SettingsManager>(context, listen: false)
                      .progressColor,
                ),
                _buildStatChip(
                  context,
                  Icons.fast_forward,
                  data.skips.toString(),
                  Provider.of<SettingsManager>(context, listen: false)
                      .skipColor,
                ),
                _buildStatChip(
                  context,
                  Icons.close_rounded,
                  data.fails.toString(),
                  Provider.of<SettingsManager>(context, listen: false)
                      .failColor,
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Monthly graph
            MonthlyGraph(data: data),
          ],
        ),
      ),
    );
  }

  Widget _buildStreakItem(BuildContext context, IconData icon, String label,
      String value, Color iconColor) {
    return Column(
      children: [
        Icon(
          icon,
          color: iconColor,
          size: 32,
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Theme.of(context).colorScheme.onSurface,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildStatChip(
      BuildContext context, IconData icon, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: color,
            size: 20,
          ),
          const SizedBox(width: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
        ],
      ),
    );
  }
}
