import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:user_screen/src/generated/l10n.dart';
import 'package:user_screen/src/settings/settings_manager.dart';
import 'package:user_screen/src/statistics/statistics.dart';
import 'package:provider/provider.dart';

class OverallStatisticsCard extends StatelessWidget {
  const OverallStatisticsCard(
      {super.key, required this.total, required this.habits});

  final OverallStatisticsData total;
  final int habits;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Theme.of(context).colorScheme.primaryContainer,
            Theme.of(context).colorScheme.secondaryContainer,
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).shadowColor.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Overview',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color:
                        Theme.of(context).colorScheme.primary.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '$habits ${S.of(context).habits}',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Pie Chart
            SizedBox(
              height: 200,
              child: Stack(
                children: [
                  PieChart(
                    PieChartData(
                      sections: showingSections(context),
                      sectionsSpace: 2,
                      centerSpaceRadius: 70,
                    ),
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  ),
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Total',
                          style: TextStyle(
                            fontSize: 16,
                            color: Theme.of(context)
                                .colorScheme
                                .onSurface
                                .withOpacity(0.6),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          (total.checks +
                                  total.progress +
                                  total.fails +
                                  total.skips)
                              .toString(),
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.onSurface,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),

            // Stats Grid
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface.withOpacity(0.5),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildStatItem(
                    context,
                    Icons.check_circle,
                    total.checks.toString(),
                    'Completed',
                    Provider.of<SettingsManager>(context, listen: false)
                        .checkColor,
                  ),
                  _buildDivider(context),
                  _buildStatItem(
                    context,
                    Icons.trending_up,
                    total.progress.toString(),
                    'Progress',
                    Provider.of<SettingsManager>(context, listen: false)
                        .progressColor,
                  ),
                  _buildDivider(context),
                  _buildStatItem(
                    context,
                    Icons.fast_forward,
                    total.skips.toString(),
                    'Skipped',
                    Provider.of<SettingsManager>(context, listen: false)
                        .skipColor,
                  ),
                  _buildDivider(context),
                  _buildStatItem(
                    context,
                    Icons.close_rounded,
                    total.fails.toString(),
                    'Failed',
                    Provider.of<SettingsManager>(context, listen: false)
                        .failColor,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(BuildContext context, IconData icon, String value,
      String label, Color color) {
    return Expanded(
      child: Column(
        children: [
          Icon(
            icon,
            color: color,
            size: 28,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildDivider(BuildContext context) {
    return Container(
      height: 50,
      width: 1,
      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.1),
    );
  }

  List<PieChartSectionData> showingSections(BuildContext context) {
    return [
      if (total.checks != 0)
        PieChartSectionData(
          color:
              Provider.of<SettingsManager>(context, listen: false).checkColor,
          value: total.checks.toDouble(),
          badgeWidget: const Icon(
            Icons.check,
            color: Colors.white,
            size: 16,
          ),
          title: '',
          radius: 40.0,
          titleStyle: const TextStyle(
              fontSize: 16.0, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      if (total.skips != 0)
        PieChartSectionData(
          color: Provider.of<SettingsManager>(context, listen: false).skipColor,
          value: total.skips.toDouble(),
          badgeWidget: const Icon(
            Icons.fast_forward,
            color: Colors.white,
            size: 16,
          ),
          title: '',
          radius: 40.0,
          titleStyle: const TextStyle(
              fontSize: 16.0, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      if (total.progress != 0)
        PieChartSectionData(
          color: Provider.of<SettingsManager>(context, listen: false)
              .progressColor,
          value: total.progress.toDouble(),
          badgeWidget: const Icon(
            Icons.trending_up,
            color: Colors.white,
            size: 16,
          ),
          title: '',
          radius: 40.0,
          titleStyle: const TextStyle(
              fontSize: 16.0, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      if (total.fails != 0)
        PieChartSectionData(
          color: Provider.of<SettingsManager>(context, listen: false).failColor,
          value: total.fails.toDouble(),
          badgeWidget: const Icon(
            Icons.close_rounded,
            color: Colors.white,
            size: 16,
          ),
          title: '',
          radius: 40.0,
          titleStyle: const TextStyle(
              fontSize: 16.0, fontWeight: FontWeight.bold, color: Colors.white),
        ),
    ];
  }
}
