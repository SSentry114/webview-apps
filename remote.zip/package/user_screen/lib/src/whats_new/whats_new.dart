// Platform-specific imports removed — iOS-only app
import 'package:flutter/material.dart';
import 'package:user_screen/src/constants.dart';
import 'package:user_screen/src/generated/l10n.dart';
import 'package:user_screen/src/settings/settings_manager.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class WhatsNew extends StatelessWidget {
  const WhatsNew({super.key});

  void _markSeen(BuildContext context) {
    final settings = Provider.of<SettingsManager>(context, listen: false);
    final current = settings.getCurrentAppVersion;
    if (current.isNotEmpty) {
      settings.setLastWhatsNewVersion = current;
    }
  }

  Future<void> _launchHaboSync() async {
    final uri = Uri.parse('https://habo.space/sync');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final version = Provider.of<SettingsManager>(context, listen: false)
        .getCurrentAppVersion;

    final pages = <PageViewModel>[
      PageViewModel(
        titleWidget: SafeArea(
          top: true,
          bottom: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                S.of(context).whatsNewTitle,
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              if (version.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Text(
                    S.of(context).whatsNewVersion(version),
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.textTheme.bodySmall?.color
                          ?.withValues(alpha: 0.7),
                    ),
                  ),
                ),
            ],
          ),
        ),
        bodyWidget: SafeArea(
          left: true,
          right: true,
          top: false,
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Icon(Icons.push_pin_outlined,
                      color: HaboColors.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      S.of(context).featureNumericTitle,
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                ]),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.only(left: 34.0),
                  child: Text(S.of(context).featureNumericDesc),
                ),
                const SizedBox(height: 16),

                Row(children: [
                  const Icon(Icons.link, color: HaboColors.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      S.of(context).featureDeepLinksTitle,
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                ]),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.only(left: 34.0),
                  child: Text(S.of(context).featureDeepLinksDesc),
                ),
                const SizedBox(height: 16),

                Row(children: [
                  const Icon(Icons.category, color: HaboColors.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      S.of(context).featureCategoriesTitle,
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                ]),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.only(left: 34.0),
                  child: Text(S.of(context).featureCategoriesDesc),
                ),
                const SizedBox(height: 16),

                Row(children: [
                  const Icon(Icons.inventory_2_outlined,
                      color: HaboColors.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      S.of(context).featureArchiveTitle,
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                ]),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.only(left: 34.0),
                  child: Text(S.of(context).featureArchiveDesc),
                ),
                const SizedBox(height: 16),

                // Material You (Android) removed — iOS-only app

                Row(children: [
                  const Icon(Icons.volume_up_outlined,
                      color: HaboColors.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      S.of(context).featureSoundTitle,
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                ]),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.only(left: 34.0),
                  child: Text(S.of(context).featureSoundDesc),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    ];
    return IntroductionScreen(
      pages: pages,
      done: Text(S.of(context).done,
          style: const TextStyle(fontWeight: FontWeight.w600)),
      onDone: () {
        _markSeen(context);
        Navigator.of(context).maybePop();
      },
      next: const Icon(Icons.arrow_forward),
      showSkipButton: true,
      skip: Text(S.of(context).skip),
      onSkip: () {
        _markSeen(context);
        Navigator.of(context).maybePop();
      },
      dotsDecorator: const DotsDecorator(activeColor: HaboColors.primary),
    );
  }
}
