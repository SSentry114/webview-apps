import 'package:flutter/material.dart';
import 'package:user_screen/user_screen.dart';

void main() {
  runApp(UserScreen());
}
