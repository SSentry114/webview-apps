class AppConfig {
  // App settings
  static const String appName = 'Home Energy Monitor';
  static final String webViewUrl = 'https://verse-dice-32437238.figma.site';
}
